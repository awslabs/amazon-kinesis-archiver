# Lambda AutoScaling Group Middleman

This Lambda function consumes SNS messages from an AutoScaling group, and will perform a variety of administrative functions to instances as they are created. It finds resources to orchestrate on the basis of Tag "LinkedASG" and the value of the AutoScaling Group Name. 

For instance, if I tag Elastic Network Interfaces with LinkedASG=MyASG, then when MyASG adds new instances, the Lambda function will be notified and will attempt to add any unallocated ENI's with this tag to the newly created instance. If you require 10 instances have known private IP addresses, then simply create 10 ENI's and tag them accordingly, and this function will ensure each one gets an ENI from this set.

## Supported Resources

Elastic Network Interfaces

EBS Volumes


## Developing

New modules can be added by creating an orchestration function that provides interface:

```
exports.myFunction = function(event, messageContents, callback) 

Where event is the SNS event raised to AWS Lambda
      messageContents is the JSON Object which is the parsed SNS message
      callback(err, result) is the callback function which you call when your module has completed. It takes arguments
         err - Errors Raised
         result - The non error result of the function execution, including {status:String, msg:String}
```

You then register your new module in the ```functions``` array that is in module ```exports.processSNSEvent```. The architecture of the function will then apply your function in parallel and do all the necessary logging and alerting.


## Testing

You can test the module with ```test.js``` which allows you type in a dummy SNS message body and event, and then allows running with ```node test```. Simples.
